package com.cogent.Assesment1;

public class TesterSchoolRecords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SchoolRecords sr = new SchoolRecords(); 
		sr.addRecords();
		sr.displayRecords();

	}

}

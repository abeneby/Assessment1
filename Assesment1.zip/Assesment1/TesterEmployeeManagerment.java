package com.cogent.Assesment1;

public class TesterEmployeeManagerment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeManagement.add();
		EmployeeManagement em = new EmployeeManagement(); 
		em.delete();

	}

}

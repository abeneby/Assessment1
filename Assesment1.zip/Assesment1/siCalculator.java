package com.cogent.Assesment1;


public class siCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float rateOfInterest = 3.5f; 
		double principal = 2000.00; 
		int numofYear = 8; 
		double si = (principal*numofYear*rateOfInterest)/100; 
		System.out.println("interest is: " + si);

	}

}

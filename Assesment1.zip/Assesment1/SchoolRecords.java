package com.cogent.Assesment1;

public class SchoolRecords {
	
	String schoolName = " Clemson University "; 
	int schoolID = 2323; 
	String schoolAddress = " 1234 River Ave. Willow, SC "; 
	
	void addRecords() {
		System.out.println(" Adding " + schoolID + schoolName + schoolAddress + " to records ");
	}
	
	void displayRecords() {
		System.out.println(" Displaying " + schoolID + schoolName + schoolAddress); 
	}
	

}

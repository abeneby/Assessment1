package com.cogent.Assesment1;

public class EmployeeManagement {
	
	static void add() {
		System.out.println("This is a static method and I am adding employee");		
	}

	EmployeeManagement() {
		System.out.println(" This is a constructor, I am displaying Information for the Employee ");
		
	}
	void delete() {
		System.out.println(" This is a normal method and I am deleting employee Infomation");
		
	}
	
}
